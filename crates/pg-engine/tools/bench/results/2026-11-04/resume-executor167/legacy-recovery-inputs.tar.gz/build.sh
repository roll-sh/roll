#!/bin/sh
# Under heavy.sh: dist builds of base (clean copy) and new (the worktree), binaries copied aside.
export PATH=/home/meszmate/.cargo/bin:$PATH TMPDIR=/home/meszmate/.cache/a167/tmp
C=/home/meszmate/.cache/a167
W=/home/meszmate/roll/.claude/worktrees/agent-a6193f5e45a7ae4f1
set -e
if [ "${SKIP_BASE:-}" = "" ] && [ ! -x $C/bin/base/roll-engine ]; then
  cd $C/base
  CARGO_TARGET_DIR=$C/target-base cargo build --profile dist -p pg-engine --bin roll-engine --example bench
  mkdir -p $C/bin/base && cp $C/target-base/dist/roll-engine $C/target-base/dist/examples/bench $C/bin/base/
  echo BASE-BUILT
fi
cd $W
CARGO_TARGET_DIR=$C/target cargo build --profile dist -p pg-engine --bin roll-engine --example bench
mkdir -p $C/bin/new && cp $C/target/dist/roll-engine $C/target/dist/examples/bench $C/bin/new/
echo NEW-BUILT
