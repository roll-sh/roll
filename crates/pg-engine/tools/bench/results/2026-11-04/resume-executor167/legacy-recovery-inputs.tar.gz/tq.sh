#!/bin/sh
# tq.sh <pg|engine> <q list, comma separated> [reps]   timed TPC-H queries (bench client)
sh /home/meszmate/.cache/a167/benv.sh bench $1 tpch --db tpch --only $2 --reps ${3:-3} --timeout 900 2>&1 | grep RESULT | sed 's/RESULT\t//' | cut -c1-200
