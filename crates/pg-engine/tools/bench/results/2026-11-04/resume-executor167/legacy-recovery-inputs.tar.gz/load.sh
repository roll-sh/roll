#!/bin/sh
L=/home/meszmate/.cache/a167/logs
B=/home/meszmate/.cache/a167/benv.sh
for t in pg engine; do
  sh $B bench $t createdb --db tpch > $L/createdb-$t.log 2>&1
  sh $B bench $t tpch-load --sf 1 --db tpch > $L/load-$t.log 2>&1
done
echo LOADS-DONE >> $L/load-engine.log
