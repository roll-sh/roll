#!/bin/sh
# q.sh <pg|engine> <sql | qNN> [explain-prefix]   psql against a167's servers, db tpch
t=$1; shift
port=53341; [ "$t" = pg ] && port=53340
sql=$1
case $sql in
q[0-9][0-9]) sql=$(grep "(\"$sql\"" /home/meszmate/roll/.claude/worktrees/agent-a6193f5e45a7ae4f1/crates/pg-engine/tools/bench/tpch.rs | sed 's/^[^,]*, "//; s/"),$//');;
esac
[ -n "${2:-}" ] && sql="$2 $sql"
exec sg docker -c "docker exec -i a167-psql psql -h 127.0.0.1 -p $port -U postgres -d ${DB:-tpch} -X -P pager=off" <<EOF
$sql
EOF
