#!/bin/sh
# round.sh <out-dir> <label...>   labels: pg | base | new (bin dirs under bin/). One TPC-H SF1 pass
# each (all 22, a warm-up first; engines on a fresh server, perf stat of user instructions).
C=/home/meszmate/.cache/a167
out=$1; shift
mkdir -p $out
B=$C/benv.sh
for l in "$@"; do
  if [ "$l" = pg ]; then
    sh $B bench pg tpch --db tpch --reps 1 --timeout 900 > /dev/null 2>&1
    sh $B bench pg tpch --db tpch --reps 1 --timeout 900 > $out/pg.$(date +%s).txt 2>&1
    continue
  fi
  BIN=$C/bin/$l sh $B engine-stop > /dev/null 2>&1
  BIN=$C/bin/$l sh $B engine-start > /dev/null 2>&1 || { echo "start $l failed"; continue; }
  pid=$(cat $C/bench/engine.pid)
  BIN=$C/bin/$l sh $B bench engine tpch --db tpch --reps 1 --timeout 900 > /dev/null 2>&1
  t=$(date +%s)
  sg docker -c "docker exec -d a167-perf perf stat -x, -e instructions:u,cycles:u -p $pid -o $C/perf/stat.$l.$t"
  sleep 1
  BIN=$C/bin/$l sh $B bench engine tpch --db tpch --reps 1 --timeout 900 > $out/$l.$t.txt 2>&1
  pp=$(sg docker -c "docker exec a167-perf pgrep -x perf" | head -1)
  sg docker -c "docker exec a167-perf kill -INT $pp"
  sleep 2
  cp $C/perf/stat.$l.$t $out/$l.$t.stat
  BIN=$C/bin/$l sh $B engine-stop > /dev/null 2>&1
done
echo ROUND-DONE
