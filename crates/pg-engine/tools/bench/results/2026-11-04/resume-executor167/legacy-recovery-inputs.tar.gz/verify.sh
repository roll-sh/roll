#!/bin/sh
# Under heavy.sh: the whole verification of the worktree, each step's tail in $L/v-<step>.log.
# Needs (outside the slot): a167-iref (default reference, host network, port 53343),
# a167-ref1 + a167-psql1 (regress), a167-dclient (pg_dump client).
export PATH=/home/meszmate/.cargo/bin:$PATH TMPDIR=/home/meszmate/.cache/a167/tmp
export CARGO_TARGET_DIR=/home/meszmate/.cache/a167/target
C=/home/meszmate/.cache/a167
L=$C/logs/verify; mkdir -p $L
W=/home/meszmate/roll/.claude/worktrees/agent-a6193f5e45a7ae4f1
cd $W
STEPS=${STEPS:-golden_record release debug clippy difftest isolation regress dumptap}
IMG=postgres@sha256:77f585114c32fbca283dc835b0596f4e52b51b4c6662d7810b2f4084f60a1873
seeds=$(seq -s, 1 30)
run() { name=$1; shift; echo "== $name $(date +%T)"; "$@" > $L/v-$name.log 2>&1; echo "== $name exit $? $(date +%T)"; }
for s in $STEPS; do
  case $s in
  golden_record)
    run golden_record env GOLDEN_RECORD=127.0.0.1:53343 GOLDEN_PASSWORD=pw GOLDEN_FILTER=a167_ \
      cargo test --release -p pg-engine --test golden ;;
  release)
    run release env CRASH_SEEDS=$seeds cargo test --release -p pg-engine --no-fail-fast ;;
  debug)
    run debug env CRASH_SEEDS=$seeds cargo test -p pg-engine --no-fail-fast ;;
  clippy)
    run clippy cargo clippy -p pg-engine --all-targets ;;
  difftest)
    run difftest env DIFFTEST_REF=127.0.0.1:53343 DIFFTEST_PASSWORD=pw DIFFTEST_DB=a167dt \
      cargo test --release -p pg-engine --test difftest -- --ignored --nocapture smoke ;;
  isolation)
    run isolation env PGISOLATION_REF=127.0.0.1:53343 PGISOLATION_PASSWORD=pw PGISOLATION_PORT=53346 \
      PGISOLATION_DIR=$C/iso PGISOLATION_REPORT_DIR=$C/iso/report PGISOLATION_EXTRA=1 \
      cargo test --release -p pg-engine --test pg_isolation -- --ignored --nocapture ;;
  regress)
    cargo build -p pg-engine --bin roll-engine > $L/v-regress-build.log 2>&1
    run regress env PGREGRESS_DIR=$C/pgr1 PGREGRESS_DB=regression_a167 PGREGRESS_PORT=53344 \
      PGREGRESS_CONTAINER=a167-ref1 PGREGRESS_ENGINE_CONTAINER=a167-psql1 \
      PGREGRESS_REPORT_DIR=$C/pgr1/report \
      cargo test -p pg-engine --test pg_regress -- pg_regress --exact --ignored --nocapture ;;
  dumptap)
    run dumptap env PGDUMP_DIR=$C/pgdump PGREGRESS_DIR=$C/pgr1 PGDUMP_CLIENT=a167-dclient PGDUMP_PORT=53345 \
      PGDUMP_REPORT_DIR=$C/pgdump/report \
      cargo test --release -p pg-engine --test pg_dump -- --ignored --nocapture pg_dump_tap ;;
  esac
done
echo VERIFY-DONE
