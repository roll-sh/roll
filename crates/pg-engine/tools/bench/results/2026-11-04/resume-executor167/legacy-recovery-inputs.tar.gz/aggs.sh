#!/bin/sh
# aggs.sh <pg|engine> q..   the aggregate lines of each query's plan
t=$1; shift
for q in "$@"; do
  echo "== $q $(sh /home/meszmate/.cache/a167/q.sh $t $q 'explain (costs off)' 2>&1 | grep -E 'Aggregate|Group Key|Gather' | tr -s ' ' | tr '\n' '|' | cut -c1-260)"
done
