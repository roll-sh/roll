#!/bin/sh
# a167 bench env; usage: benv.sh <run.sh args...>   (BIN=dir overrides the binaries)
export BENCH_BIN=${BIN:-/home/meszmate/.cache/a167/bin/borrow}
export PG_NAME=a167-pg ENGINE_NAME=a167-engine ENGINE_DOCKER=1 ENGINE_PORT=53341 PG_PORT=53340
export SERVER_CPUS=4-7 CLIENT_CPUS=8-11 BENCH_DATA=/home/meszmate/.cache/a167/bench PG_NETWORK=host
exec nice -n 19 /home/meszmate/roll/.claude/worktrees/agent-a6193f5e45a7ae4f1/crates/pg-engine/tools/bench/run.sh "$@"
