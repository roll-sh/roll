export PATH=$HOME/.cargo/bin:$PATH
export TMPDIR=$HOME/.cache/a167/tmp
export CARGO_TARGET_DIR=$HOME/.cache/a167/target
H=/home/meszmate/roll/.claude/worktrees/agent-a6193f5e45a7ae4f1/crates/pg-engine/tools/heavy-bg.sh
L=$HOME/.cache/a167/logs
