#!/bin/sh
# prof.sh <qNN> <reps> <out> [perf record args]   flat profile of the engine while qNN runs reps times
q=$1; reps=$2; out=$3; shift 3
pid=$(cat /home/meszmate/.cache/a167/bench/engine.pid)
D=/home/meszmate/.cache/a167/perf; mkdir -p $D
sh /home/meszmate/.cache/a167/q.sh engine $q > /dev/null 2>&1
sg docker -c "docker exec a167-perf perf record -F 999 ${*:-} -p $pid -o $D/$out" > $D/$out.rec.log 2>&1 &
sleep 1
i=0; while [ $i -lt $reps ]; do sh /home/meszmate/.cache/a167/q.sh engine $q > /dev/null 2>&1; i=$((i+1)); done
pp=$(sg docker -c "docker exec a167-perf pgrep -x perf" | head -1)
sg docker -c "docker exec a167-perf kill -INT $pp"
wait
sg docker -c "docker exec a167-perf perf report -i $D/$out --stdio --no-children --percent-limit 0.7 --sort sym" 2>/dev/null | grep -v '^#' | grep -v '^$' | head -60
