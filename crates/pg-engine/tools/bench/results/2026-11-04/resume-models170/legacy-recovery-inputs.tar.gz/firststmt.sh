#!/bin/bash
# The first statement after a clean restart, lifted limit, scale 10 (lift.sh's bulk check's
# last step), on a host engine: firststmt.sh <engine binary> <label>
# Prints the statement's \timing (ms) and whether its EXPLAIN matches the one before the restart.
set -euo pipefail
BIN=${1:?engine}; L=${2:?label}
W=$HOME/.cache/a170/first; D=$W/data-$L; mkdir -p "$W"; rm -rf "$D"; mkdir -p "$D"
PORT=53411; SCALE=${SCALE:-10}
IMG=postgres@sha256:77f585114c32fbca283dc835b0596f4e52b51b4c6662d7810b2f4084f60a1873
ss -ltn | grep -q ":$PORT " && { echo "port $PORT busy"; exit 1; }
pid=
start() {
  ROLL_MODEL_MAX_VERSIONS=${LIMIT:-1099511627776} TMPDIR=$D nice -n 19 taskset -c 32-35 "$BIN" --data "$D" \
    --listen 127.0.0.1:$PORT --password pw --cache-mb 2048 >> "$W/engine-$L.log" 2>&1 &
  pid=$!
  until ss -ltn | grep -q ":$PORT "; do sleep 0.1; done
}
stop() { [ -n "$pid" ] && kill $pid 2>/dev/null && while kill -0 $pid 2>/dev/null; do sleep 0.2; done; pid=; }
trap stop EXIT
cli() { docker run --rm -i --network host --cpuset-cpus 12-13 -e PGPASSWORD=pw "$IMG" "$@"; }
start
cli psql -X -q -h 127.0.0.1 -p $PORT -U postgres -d postgres -c "CREATE DATABASE bench"
cli pgbench -i -s $SCALE -h 127.0.0.1 -p $PORT -U postgres bench > /dev/null 2>&1
cli psql -X -q -h 127.0.0.1 -p $PORT -U postgres -d bench -c "DELETE FROM pgbench_accounts WHERE aid % 10 = 0" -c "VACUUM pgbench_accounts"
Q="SELECT abalance FROM pgbench_accounts WHERE aid = 12345;"
E="EXPLAIN SELECT abalance FROM pgbench_accounts WHERE aid = 12345;"
before=$(echo "$E" | cli psql -X -At -h 127.0.0.1 -p $PORT -U postgres -d bench)
for i in 1 2 3; do
  stop; start
  ms=$(printf '\\timing on\n%s\n' "$Q" | cli psql -X -At -h 127.0.0.1 -p $PORT -U postgres -d bench | sed -n 's/^Time: \([0-9.]*\) ms.*/\1/p')
  after=$(echo "$E" | cli psql -X -At -h 127.0.0.1 -p $PORT -U postgres -d bench)
  same=differs; [ "$before" = "$after" ] && same=same
  echo "FIRST $L restart $i ms=$ms explain=$same"
done
echo "$before" | head -2
