#!/bin/bash
# a170's verification of the snapshot in ~/.cache/a170/headsrc, one heavy job:
#   heavy-bg.sh <log> bash verify.sh [stages...]
# stages (default all): release debug crash clippy smoke isolation regress dump
# Each stage writes ~/.cache/a170/verify/<stage>.log and a "STAGE <name> <status>" line.
set -u
. $HOME/.cache/a170/env.sh
V=$HOME/.cache/a170/verify; mkdir -p "$V"
SRC=$HOME/.cache/a170/headsrc
cd "$SRC"
IMG=postgres@sha256:77f585114c32fbca283dc835b0596f4e52b51b4c6662d7810b2f4084f60a1873
STAGES=${*:-release debug crash clippy smoke isolation regress dump}
echo "verify $(cat SNAPSHOT) stages: $STAGES"
stage() { local n=$1; shift; "$@" > "$V/$n.log" 2>&1; echo "STAGE $n $?"; }
free() { ! ss -ltn "sport = :$1" | grep -q LISTEN; }
for s in $STAGES; do
  case $s in
  record)
    for g in ${GOLDENS:-}; do
      : > crates/pg-engine/tests/sql/$g.out
      GOLDEN_RECORD=127.0.0.1:53405 GOLDEN_PASSWORD=pw GOLDEN_FILTER=$g stage record-$g cargo test -p pg-engine --release --test golden
      cp crates/pg-engine/tests/sql/$g.out $V/$g.out
    done ;;
  release) stage release cargo test -p pg-engine --release ;;
  debug) stage debug cargo test -p pg-engine ;;
  crash) CRASH_SEEDS=$(seq -s, 1 30) CRASH_ROUNDS=4 stage crash cargo test -p pg-engine --release --test crash_random ;;
  clippy) stage clippy cargo clippy -p pg-engine --all-targets ;;
  smoke)
    free 53406 || { echo "STAGE smoke port"; continue; }
    docker rm -fv a170-dref >/dev/null 2>&1
    docker run -d --name a170-dref --network host -e POSTGRES_PASSWORD=pw -e POSTGRES_INITDB_ARGS="--locale=C --encoding=UTF8" \
      "$IMG" -c port=53406 -c listen_addresses=127.0.0.1 >/dev/null
    sleep 8
    DIFFTEST_REF=127.0.0.1:53406 DIFFTEST_DB=difftest_a170 stage smoke cargo test -p pg-engine --release --test difftest -- --ignored --nocapture smoke
    docker rm -fv a170-dref >/dev/null 2>&1 ;;
  isolation)
    free 53406 && free 53407 || { echo "STAGE isolation port"; continue; }
    docker rm -fv a170-iref >/dev/null 2>&1
    docker run -d --name a170-iref --network host -e POSTGRES_PASSWORD=pw -e POSTGRES_INITDB_ARGS="--locale=C --encoding=UTF8" \
      "$IMG" -c port=53406 -c listen_addresses=127.0.0.1 >/dev/null
    sleep 8
    PGISOLATION_DIR=$HOME/.cache/a170/iso PGISOLATION_PORT=53407 PGISOLATION_REF=127.0.0.1:53406 \
      PGISOLATION_REPORT_DIR=$V/isolation stage isolation cargo test -p pg-engine --release --test pg_isolation -- --ignored --nocapture
    docker rm -fv a170-iref >/dev/null 2>&1 ;;
  regress)
    free 53408 || { echo "STAGE regress port"; continue; }
    D=$HOME/.cache/a170/pgr
    docker rm -fv a170-rref a170-rpsql >/dev/null 2>&1
    docker run -d --name a170-rref -e POSTGRES_PASSWORD=pw -e POSTGRES_INITDB_ARGS="--locale=C --encoding=UTF8" "$IMG" >/dev/null
    docker run -d --name a170-rpsql --network host --user "$(id -u):$(id -g)" -v "$D:$D" --entrypoint sleep "$IMG" infinity >/dev/null
    sleep 8
    PGREGRESS_DIR=$D PGREGRESS_DB=regression_a170 PGREGRESS_PORT=53408 PGREGRESS_CONTAINER=a170-rref \
      PGREGRESS_ENGINE_CONTAINER=a170-rpsql PGREGRESS_REPORT_DIR=$V/regress PGREGRESS_COMMIT="$(cat SNAPSHOT)" \
      PGREGRESS_BASELINE=$SRC/crates/pg-engine/tests/regress/results.tsv \
      stage regress cargo test -p pg-engine --release --test pg_regress -- pg_regress --exact --ignored --nocapture
    docker rm -fv a170-rref a170-rpsql >/dev/null 2>&1 ;;
  dump)
    free 53409 || { echo "STAGE dump port"; continue; }
    D=$HOME/.cache/a170/pgdump; mkdir -p "$D"
    docker rm -fv a170-dclient >/dev/null 2>&1
    docker run -d --name a170-dclient --network host --user "$(id -u):$(id -g)" -v "$D:$D" --entrypoint sleep "$IMG" infinity >/dev/null
    PGDUMP_DIR=$D PGDUMP_CLIENT=a170-dclient PGDUMP_PORT=53409 PGDUMP_SRC=$HOME/.cache/a170/pgr/src-repo \
      PGDUMP_REPORT_DIR=$V/pgdump stage dump cargo test -p pg-engine --release --test pg_dump -- --ignored --nocapture pg_dump_tap
    docker rm -fv a170-dclient >/dev/null 2>&1 ;;
  esac
done
