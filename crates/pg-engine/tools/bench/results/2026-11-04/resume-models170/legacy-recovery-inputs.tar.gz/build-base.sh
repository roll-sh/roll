#!/bin/sh
# Baseline dist and release engine binaries of origin's 5c312235, from an exported tree with a
# target dir of its own (never the worktree's: it has a170's edits).
set -e
. $HOME/.cache/a170/env.sh
export CARGO_TARGET_DIR=$HOME/.cache/a170/target-base
src=$HOME/.cache/a170/basesrc
rm -rf "$src"; mkdir -p "$src"
git -C /home/meszmate/roll/.claude/worktrees/agent-a0718617fe2ff9006 archive 5c312235 | tar -x -C "$src"
cd "$src"
cargo build -p pg-engine --profile dist --bin roll-engine
cp $CARGO_TARGET_DIR/dist/roll-engine $HOME/.cache/a170/base/roll-engine-dist
cargo build -p pg-engine --release --bin roll-engine
cp $CARGO_TARGET_DIR/release/roll-engine $HOME/.cache/a170/base/roll-engine-release
