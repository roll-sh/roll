#!/bin/sh
# Snapshot a commit of the worktree (default HEAD) into ~/.cache/a170/headsrc for builds and
# tests (SNAPSHOT names it).
set -e
wt=/home/meszmate/roll/.claude/worktrees/agent-a0718617fe2ff9006
rev=$(git -C "$wt" rev-parse "${1:-HEAD}")
dst=$HOME/.cache/a170/headsrc
rm -rf "$dst"; mkdir -p "$dst"
git -C "$wt" archive "$rev" | tar -x -C "$dst"
echo "$rev" > "$dst/SNAPSHOT"
echo "snapshot of $rev: $(git -C "$wt" log --format=%s -1 "$rev")"
