#!/bin/sh
# a170's page-count reference (a170-mwref, port 53405, autovacuum off as round 5's runs) and
# psql helper (a170-psql).
IMG=postgres@sha256:77f585114c32fbca283dc835b0596f4e52b51b4c6662d7810b2f4084f60a1873
docker run -d --name a170-mwref --network host --cpuset-cpus 24-27 --memory 2g -e POSTGRES_PASSWORD=pw \
  -e POSTGRES_INITDB_ARGS="--locale=C --encoding=UTF8" "$IMG" -c port=53405 -c listen_addresses=127.0.0.1 \
  -c autovacuum=off >/dev/null
docker run -d --name a170-psql --network host --cpuset-cpus 12-13 --entrypoint sleep "$IMG" infinity >/dev/null
docker ps --filter name=a170- --format '{{.Names}} {{.Status}}'
