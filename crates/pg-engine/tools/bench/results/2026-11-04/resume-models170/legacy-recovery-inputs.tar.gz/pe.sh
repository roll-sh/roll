#!/bin/sh
# Delete patterns on PostgreSQL that leave an empty leaf VACUUM can't delete.
for pat in "id % 1000 < 900" "id > 2000 AND id < 150000" "id % 50000 > 20000" "id BETWEEN 90000 AND 130000" "id % 100000 > 1000"; do
  out=$(sed "s/id % 1000 < 700/$pat/" /home/meszmate/.cache/a170/pe.sql | docker exec -i -e PGPASSWORD=pw a170-psql psql -X -q -At -h 127.0.0.1 -p 53405 -U postgres postgres 2>/dev/null | tr '\n' ' ')
  echo "$out <- $pat"
done
