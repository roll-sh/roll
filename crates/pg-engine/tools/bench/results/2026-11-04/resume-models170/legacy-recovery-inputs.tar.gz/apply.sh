#!/bin/sh
# a170's apply runs: apply.sh with a170's ports and cores. Extra environment passes through
# (ENGINE, BASE, ROUNDS, PERF, ENGINE_DOCKER ...).
export A=a170 PORT0=53400 WORK=$HOME/.cache/a170/bench
export E_CPUS=${E_CPUS:-32-35} PG_CPUS=${PG_CPUS:-24-27} C_CPUS=${C_CPUS:-12-13}
export PATH=$HOME/.cargo/bin:$PATH
cd /home/meszmate/roll/.claude/worktrees/agent-a0718617fe2ff9006/crates/pg-engine
exec sg docker -c "sh tools/bench/repl/apply.sh"
