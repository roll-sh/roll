#!/bin/sh
# a170's head engine binaries (release with line tables, dist) from the snapshot in
# ~/.cache/a170/headsrc (made by snap.sh; the only checkout building in ~/.cache/a170/target).
set -e
. $HOME/.cache/a170/env.sh
cd $HOME/.cache/a170/headsrc
out=$HOME/.cache/a170/head; mkdir -p "$out"
cp SNAPSHOT "$out/SNAPSHOT"
cargo build -p pg-engine --release --bin roll-engine
cp $CARGO_TARGET_DIR/release/roll-engine "$out/roll-engine-release"
cargo build -p pg-engine --profile dist --bin roll-engine
cp $CARGO_TARGET_DIR/dist/roll-engine "$out/roll-engine-dist"
