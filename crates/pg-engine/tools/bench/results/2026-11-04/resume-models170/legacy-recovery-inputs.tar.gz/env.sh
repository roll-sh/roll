export PATH=$HOME/.cargo/bin:$PATH
export CARGO_TARGET_DIR=$HOME/.cache/a170/target
export TMPDIR=$HOME/.cache/a170/tmp
export CARGO_PROFILE_RELEASE_DEBUG=line-tables-only
