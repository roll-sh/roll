#!/bin/bash
# The lifted primary-key build (pgbench -i -I p at scale 10) on a host engine, profiled:
#   pkprof.sh <engine binary> <label>
# Engine on cores 32-35 under nice 19, port 53410, the model limit lifted (LIMIT overrides).
# Prints the process CPU of the phase (PHASE, default p); with PERF=1 writes perf-<label>.data
# and report-<label>.txt in ~/.cache/a170/pk.
set -euo pipefail
BIN=${1:?engine}; L=${2:?label}
W=$HOME/.cache/a170/pk; D=$W/data-$L; mkdir -p "$W"; rm -rf "$D"; mkdir -p "$D"
PORT=53410; SCALE=${SCALE:-10}; PHASE=${PHASE:-p}
IMG=postgres@sha256:77f585114c32fbca283dc835b0596f4e52b51b4c6662d7810b2f4084f60a1873
ss -ltn | grep -q ":$PORT " && { echo "port $PORT busy"; exit 1; }
ROLL_MODEL_MAX_VERSIONS=${LIMIT:-1099511627776} TMPDIR=$D nice -n 19 taskset -c 32-35 "$BIN" --data "$D" \
  --listen 127.0.0.1:$PORT --password pw --cache-mb 2048 > "$W/engine-$L.log" 2>&1 &
pid=$!
trap 'kill $pid 2>/dev/null; wait $pid 2>/dev/null || true' EXIT
until ss -ltn | grep -q ":$PORT "; do sleep 0.2; done
cli() { sg docker -c "docker run --rm -i --network host --cpuset-cpus 12-13 -e PGPASSWORD=pw $IMG $*"; }
cpu() { awk '{print $14 + $15}' /proc/$pid/stat; }
cli psql -X -q -h 127.0.0.1 -p $PORT -U postgres -d postgres -c "'CREATE DATABASE bench'"
cli pgbench -i -I ${PRE:-dtgv} -s $SCALE -h 127.0.0.1 -p $PORT -U postgres bench > /dev/null 2>&1
sleep ${SETTLE:-5}
c0=$(cpu); t0=$(date +%s.%N)
if [ -n "${PERF:-}" ]; then
  sg docker -c "docker exec a170-perf perf record -F 999 --call-graph lbr -p $pid -o $W/perf-$L.data -- sleep ${PERF_SECS:-6}" > /dev/null 2>&1 &
  pp=$!; sleep 0.5
fi
if [ -n "${SQL:-}" ]; then
  cli psql -X -q -h 127.0.0.1 -p $PORT -U postgres -d bench -c "'$SQL'" > /dev/null 2>&1
else
  cli pgbench -i -I $PHASE -s $SCALE -h 127.0.0.1 -p $PORT -U postgres bench > /dev/null 2>&1
fi
c1=$(cpu); t1=$(date +%s.%N)
echo "PK $L phase=$PHASE cpu_s=$(awk -v a=$c1 -v b=$c0 'BEGIN{printf "%.2f", (a-b)/100}') wall_s=$(awk -v a=$t1 -v b=$t0 'BEGIN{printf "%.2f", a-b}')"
if [ -n "${PERF:-}" ]; then
  wait $pp || true
  sg docker -c "docker exec a170-perf perf report -i $W/perf-$L.data --stdio --no-children --percent-limit 0.7 -g none" 2>/dev/null | grep -v '^#' | grep -v '^$' | head -60 > "$W/report-$L.txt"
fi
