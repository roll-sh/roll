#!/bin/sh
# usage: post2.sh: after the rebase onto 154's cols.rs: its unit test, targeted tests, clippy
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
D=/home/meszmate/.cache/a149
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp CARGO_TARGET_DIR=$D/target
cd $W
H=crates/pg-engine/tools/heavy.sh
timeout 7000 $H cargo test -p pg-engine --lib -- storage:: exec::kernel > $D/p2-lib.log 2>&1
echo "lib: $(grep -E '^test result|panicked|^error' $D/p2-lib.log | head -3 | tr '\n' ' ')"
timeout 7000 $H cargo test -p pg-engine --test stored_filters --test parallel_scan --test heap_order_scan > $D/p2-tests.log 2>&1
echo "tests: $(grep -c '^test result: ok' $D/p2-tests.log) ok, $(grep -c 'FAILED\|panicked\|^error' $D/p2-tests.log) failed lines"
timeout 7000 $H cargo clippy -p pg-engine --all-targets > $D/p2-clippy.log 2>&1
echo "clippy: $(grep -c '^warning' $D/p2-clippy.log) warnings, $(grep -c '^error' $D/p2-clippy.log) errors; mine: $(grep -A4 '^warning' $D/p2-clippy.log | grep -cE 'cols.rs|exec/scan.rs|storage/batch.rs')"
