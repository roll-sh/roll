#!/bin/sh
# usage (inside a149-perf): under.sh <out> <key> [n] [min%]: what a symbol's time goes to (callee tree)
D=/home/meszmate/.cache/a149
case $2 in
scannext) s='<pg_engine::exec::scan::ScanNode as pg_engine::exec::Node>::next' ;;
loop) s='pg_engine::server::message_loop' ;;
runq) s='<pg_engine::session::Session>::run_query' ;;
*) s=$2 ;;
esac
perf report -i $D/$1.data --stdio --children --no-inline --sort symbol -g caller,${4:-0.4},callee,function,percent -S "$s" 2>/dev/null | grep -v '^#' | grep -v '^$' | head -${3:-80} | cut -c1-170
