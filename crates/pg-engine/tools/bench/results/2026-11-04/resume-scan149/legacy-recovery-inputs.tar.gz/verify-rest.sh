#!/bin/sh
# usage: verify-rest.sh: verify-all.sh from crash_random on (binaries in vbin), with timeouts long
# enough for the heavy queue
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
D=/home/meszmate/.cache/a149
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp
cd $W/crates/pg-engine
H=tools/heavy.sh
E=$D/vbin/roll-engine-debug
T=40000
echo "start $(date +%H:%M)"
CRASH_SEEDS=$(seq -s, 1 30) timeout $T $H $D/vbin/crash_random > $D/va-crash.log 2>&1
echo "crash: $(grep -E '^test result' $D/va-crash.log | tail -1)"
rm -rf $D/pgr/report $D/pgr/out
PGREGRESS_DIR=$D/pgr PGREGRESS_DB=regression_a149 PGREGRESS_PORT=52982 \
PGREGRESS_CONTAINER=a149-ref PGREGRESS_ENGINE_CONTAINER=a149-psql \
PGREGRESS_REPORT_DIR=$D/pgr/report PGREGRESS_ENGINE_BIN=$E \
  timeout $T $H $D/vbin/pg_regress pg_regress --exact --ignored --nocapture > $D/va-regress.log 2>&1
echo "regress: $(grep 'units match' $D/va-regress.log | tail -1 | cut -c1-60) $(grep -o 'Newly differing units: [0-9]*; newly matching: [0-9]*' $D/pgr/report/REPORT.md | head -1)"
PGISOLATION_EXTRA=1 PGISOLATION_REF=127.0.0.1:52980 PGISOLATION_PORT=52983 PGISOLATION_ENGINE_BIN=$E \
PGISOLATION_DIR=$D/iso PGISOLATION_REPORT_DIR=$D/iso/report PGISOLATION_DB=isolation_a149 \
  timeout $T $H $D/vbin/pg_isolation --ignored --nocapture > $D/va-iso.log 2>&1
echo "isolation: $(grep -E 'specs,' $D/va-iso.log | tail -1 | cut -c1-90)"
DIFFTEST_REF=127.0.0.1:52980 DIFFTEST_DB=difftest_a149 timeout $T $H $D/vbin/difftest --ignored --nocapture smoke > $D/va-diff.log 2>&1
echo "difftest: $(grep -E '^test result' $D/va-diff.log | tail -1 | cut -c1-40)"
rm -rf $D/pgr/pgdump && mkdir -p $D/pgr/pgdump
PGDUMP_DIR=$D/pgr/pgdump PGDUMP_CLIENT=a149-psql PGDUMP_PORT=52984 PGREGRESS_DIR=$D/pgr PGREGRESS_DB=regression_a149 \
PGDUMP_ENGINE_BIN=$E PGDUMP_REPORT_DIR=$D/pgr/pgdump-report \
  timeout $T $H $D/vbin/pg_dump --ignored --nocapture pg_dump_tap > $D/va-dump.log 2>&1
echo "pg_dump_tap: $(grep -E 'passed, [0-9]+ failed' $D/va-dump.log | awk '{p+=$2; f+=$4} END {print p" passed, "f" failed"}')"
rm -rf $D/pgc/report
PGCONTRIB_ONLY=pgvector,bloom,pg_trgm,btree_gist,cube PGREGRESS_DIR=$D/pgc PGREGRESS_DB=contrib_regression \
PGREGRESS_PORT=52985 PGREGRESS_CONTAINER=a149-cref PGREGRESS_ENGINE_CONTAINER=a149-psql2 \
PGREGRESS_REPORT_DIR=$D/pgc/report PGREGRESS_ENGINE_BIN=$E \
  timeout $T $H $D/vbin/pg_contrib --ignored --nocapture > $D/va-contrib.log 2>&1
echo "contrib: $(grep -E '^\| (pgvector|bloom|pg_trgm|btree_gist|cube) \| [0-9]+ \| [0-9]+ \| [0-9]+ \| [0-9]+ ' $D/pgc/report/REPORT.md | awk -F'|' '{printf "%s %s/%s; ", $2, $6, $5}')"
PGVECTOR_REF=127.0.0.1:52988 timeout $T $H $D/vbin/pgvector_equality --ignored --nocapture > $D/va-veq.log 2>&1
echo "pgvector_equality: $(grep -E 'queries' $D/va-veq.log | tail -1)"
echo "end $(date +%H:%M)"
