#!/bin/sh
# usage: prof.sh <binary> <sql> <out>: perf record (flat) of one run inside a149-perf
D=/home/meszmate/.cache/a149
sg docker -c "docker exec -e TMPDIR=$D/tmp a149-perf sh -c 'nice -n 19 perf record -F 2000 -o $D/$3.data $D/q-$1 < $D/$2 > /dev/null 2>&1'"
sg docker -c "docker exec a149-perf sh -c 'perf report -i $D/$3.data --stdio --no-children --sort symbol 2>/dev/null | grep -v \"^#\" | grep -v \"^\$\" | head -45'" | cut -c1-150
