#!/bin/sh
# usage: build-sb.sh: scan_bench and q, release, for the base tree (target-base) and this worktree (target)
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
D=/home/meszmate/.cache/a149
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp
cd $D/base && CARGO_TARGET_DIR=$D/target-base timeout 7000 $W/crates/pg-engine/tools/heavy.sh cargo build --release -p pg-engine --example scan_bench --example q > $D/build-sb-base.log 2>&1
grep -E '^error|Finished' $D/build-sb-base.log | head -3
