#!/bin/sh
# usage (inside a149-perf): callers.sh <out> <symbol substring> [n]: call chains into a symbol
D=/home/meszmate/.cache/a149
perf report -i $D/$1.data --stdio --no-children --no-inline --sort symbol -g caller,0.5,callee,function,percent --symbol-filter="$2" 2>/dev/null | grep -v '^#' | grep -v '^$' | head -${3:-60} | cut -c1-170
