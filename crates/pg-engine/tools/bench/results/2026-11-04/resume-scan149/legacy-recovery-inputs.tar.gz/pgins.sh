#!/bin/sh
# usage: pgins.sh <case> <clients> <secs>: PostgreSQL's instructions and CPU per op (all its processes)
D=/home/meszmate/.cache/a149
pids=$(sg docker -c "docker top a149-pg -o pid" | tail -n +2 | tr '\n' ',' | sed 's/,$//')
nice -n 19 taskset -c 28-31 $D/bench --target wire --host 127.0.0.1 --port 52980 --db bench oltp --rows 200000 --only $1 --clients $2 --secs 2 > /dev/null 2>&1
# (backends started by the bench connect after; count the whole cgroup instead)
sg docker -c "docker exec -d a149-perf sh -c 'perf stat -x, -e instructions:u -a -G system.slice/docker-$(cat $D/pg-cid).scope -o $D/pg-stat.txt -- sleep $(($3 + 1))'"
sleep 0.3
out=$(sh $D/rr.sh pg 52980 $1 $2 $3)
sleep 1.5
ops=$(echo "$out" | head -1 | tr ' ' '\n' | awk -F= '$1=="ops"{print $2}')
tps=$(echo "$out" | head -1 | tr ' ' '\n' | awk -F= '$1=="tps"{print $2}')
cpu=$(echo "$out" | tail -1 | tr ' ' '\n' | awk -F= '$1=="server_cpu_us"{print $2}')
ins=$(grep instructions $D/pg-stat.txt | cut -d, -f1)
echo "pg tps=$tps cpu_us_per_op=$(awk "BEGIN{printf \"%.1f\", $cpu/$ops}") kinsn_per_op=$(awk "BEGIN{printf \"%.0f\", $ins/$ops/1000}")"
