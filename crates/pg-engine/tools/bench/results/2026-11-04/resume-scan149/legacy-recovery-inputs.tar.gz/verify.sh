#!/bin/sh
# usage: verify.sh: crate tests (debug, release), spill tests, clippy; logs in ~/.cache/a149/v-*.log
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
D=/home/meszmate/.cache/a149
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp CARGO_TARGET_DIR=$D/target
cd $W
H=crates/pg-engine/tools/heavy.sh
timeout 7000 $H cargo test -p pg-engine --no-fail-fast > $D/v-debug.log 2>&1
echo "debug done: $(grep -c '^test result: ok' $D/v-debug.log) ok, $(grep -c 'FAILED\|panicked' $D/v-debug.log) failed lines"
timeout 7000 $H cargo test --release -p pg-engine --no-fail-fast > $D/v-release.log 2>&1
echo "release done: $(grep -c '^test result: ok' $D/v-release.log) ok, $(grep -c 'FAILED\|panicked' $D/v-release.log) failed lines"
ROLL_TXN_SPILL_BYTES=4096 timeout 7000 $H cargo test -p pg-engine --test txn_spill --test toast_storage --test drop_storage --test heap_order_scan --test stored_filters > $D/v-spill.log 2>&1
echo "spill done: $(grep -c '^test result: ok' $D/v-spill.log) ok, $(grep -c 'FAILED\|panicked' $D/v-spill.log) failed lines"
timeout 7000 $H cargo clippy -p pg-engine --all-targets > $D/v-clippy.log 2>&1
echo "clippy done: $(grep -c '^warning' $D/v-clippy.log) warnings, $(grep -c '^error' $D/v-clippy.log) errors"
