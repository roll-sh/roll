#!/bin/sh
# usage: apply-pg.sh setup | run <secs>: the apply-like mix on PostgreSQL (a149-pg, 52980), CPU from its cgroup
D=/home/meszmate/.cache/a149
P=52980
psql_() { sg docker -c "docker exec -i -e PGPASSWORD=pw a149-psql psql -h 127.0.0.1 -p $P -U postgres -q $*" 2>&1; }
pgb() { sg docker -c "docker exec -e PGPASSWORD=pw a149-psql pgbench -h 127.0.0.1 -p $P -U postgres $*" 2>&1; }
cpu() { awk '/usage_usec/ {print $2}' /sys/fs/cgroup/system.slice/docker-$(cat $D/pg-cid).scope/cpu.stat; }
case $1 in
setup)
  psql_ -c "'DROP DATABASE IF EXISTS pgb'" > /dev/null; psql_ -c "'CREATE DATABASE pgb'" > /dev/null
  psql_ -d pgb < $D/apply/extra_setup.sql | tail -1
  ;;
run)
  cp $D/apply/apply.sql $D/pgr/apply.sql
  pgb -M prepared -n -f $D/pgr/apply.sql -c 8 -j 4 -T 5 pgb > /dev/null
  c0=$(cpu); out=$(pgb -M prepared -n -f $D/pgr/apply.sql -c 8 -j 4 -T $2 pgb); c1=$(cpu)
  tx=$(echo "$out" | awk '/number of transactions actually processed/ {print $NF}' | cut -d/ -f1)
  tps=$(echo "$out" | awk '/^tps/ {print $3}')
  echo "pg apply tps=$tps cpu_ms_per_tx=$(awk "BEGIN{printf \"%.3f\", ($c1-$c0)/1000/$tx}")"
  ;;
esac
