#!/bin/sh
# usage (inside a149-perf): script.sh <out>: perf script (stacks) into <out>.txt
D=/home/meszmate/.cache/a149
perf script -i $D/$1.data --no-inline -F comm,tid,ip,sym 2>/dev/null > $D/$1.txt
chmod 644 $D/$1.txt
wc -l $D/$1.txt
