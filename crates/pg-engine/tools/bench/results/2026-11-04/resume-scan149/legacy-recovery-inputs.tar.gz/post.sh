#!/bin/sh
# usage: post.sh: after a rebase: targeted tests (debug) and clippy
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
D=/home/meszmate/.cache/a149
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp CARGO_TARGET_DIR=$D/target
cd $W
H=crates/pg-engine/tools/heavy.sh
timeout 7000 $H cargo test -p pg-engine --test stored_filters --test drop_storage --test heap_order_scan --test parallel_scan --test toast_storage > $D/p-tests.log 2>&1
echo "tests: $(grep -c '^test result: ok' $D/p-tests.log) ok, $(grep -c 'FAILED\|panicked\|^error' $D/p-tests.log) failed lines"
timeout 7000 $H cargo test -p pg-engine --lib storage:: exec:: > $D/p-lib.log 2>&1
echo "lib: $(grep -E '^test result' $D/p-lib.log | tail -1)"
timeout 7000 $H cargo clippy -p pg-engine --all-targets > $D/p-clippy.log 2>&1
echo "clippy: $(grep -c '^warning' $D/p-clippy.log) warnings, $(grep -c '^error' $D/p-clippy.log) errors; mine: $(grep -A4 '^warning' $D/p-clippy.log | grep -cE 'cols.rs|exec/scan.rs|storage/batch.rs|storage/row.rs')"
