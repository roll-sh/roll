#!/bin/sh
# usage (inside a149-perf): prof1.sh <binary> <setup sql> <measured sql> <out>
# Runs the setup, then profiles only the measured statements (attached while pg_sleep waits).
D=/home/meszmate/.cache/a149
export TMPDIR=$D/tmp
n=$(grep -c ';' $D/$2)
{ cat $D/$2; echo 'SELECT pg_sleep(1);'; cat $D/$3; echo 'SELECT pg_sleep(4);'; } > $D/$4.sql
Q_TIME=1 nice -n 19 $D/q-$1 < $D/$4.sql > /dev/null 2> $D/$4.err &
pid=$!
while [ "$(grep -c ' ms ' $D/$4.err)" -lt "$n" ]; do sleep 0.1; done
perf record -F 4000 -g -p $pid -o $D/$4.data -- sleep 3 > /dev/null 2>&1
wait $pid
cat $D/$4.err | tail -4
perf report -i $D/$4.data --stdio --no-children --sort symbol -g none 2>/dev/null | grep -v '^#' | grep -v '^$' | head -40 | cut -c1-140
