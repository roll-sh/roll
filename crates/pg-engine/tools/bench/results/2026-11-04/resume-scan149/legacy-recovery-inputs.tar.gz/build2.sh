#!/bin/sh
# usage: build2.sh: the cols unit test (debug), then the profiling engine
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
D=/home/meszmate/.cache/a149
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp
cd $W
CARGO_TARGET_DIR=$D/target timeout 7000 crates/pg-engine/tools/heavy.sh cargo test -p pg-engine --lib storage:: > $D/t3.log 2>&1
RUSTFLAGS="-C force-frame-pointers=yes" CARGO_PROFILE_RELEASE_DEBUG=line-tables-only CARGO_TARGET_DIR=$D/target-prof timeout 7000 crates/pg-engine/tools/heavy.sh cargo build --release -p pg-engine --bin roll-engine > $D/build-prof.log 2>&1
grep -E '^test result|panicked|^error' $D/t3.log | head
grep -E '^error|Finished' $D/build-prof.log | head -3
