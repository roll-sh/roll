#!/bin/sh
# usage: heavy-bg.sh <log> sh verify-refs.sh: regress and contrib again (their references had
# stopped), binaries in vbin
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
D=/home/meszmate/.cache/a149
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp
O=$D/vi.out
cd $W/crates/pg-engine
E=$D/vbin/roll-engine-debug
sg docker -c "docker start a149-ref a149-cref a149-psql a149-psql2" > /dev/null
sleep 5
rm -rf $D/pgr/report $D/pgr/out
PGREGRESS_DIR=$D/pgr PGREGRESS_DB=regression_a149 PGREGRESS_PORT=52982 \
PGREGRESS_CONTAINER=a149-ref PGREGRESS_ENGINE_CONTAINER=a149-psql \
PGREGRESS_REPORT_DIR=$D/pgr/report PGREGRESS_ENGINE_BIN=$E \
  nice -n 19 $D/vbin/pg_regress pg_regress --exact --ignored --nocapture > $D/vi-regress.log 2>&1
echo "regress: $(grep 'units match' $D/vi-regress.log | tail -1 | cut -c1-60) $(grep -o 'Newly differing units: [0-9]*; newly matching: [0-9]*' $D/pgr/report/REPORT.md | head -1)" >> $O
exit 0
rm -rf $D/pgc/report
PGCONTRIB_ONLY=pgvector,bloom,pg_trgm,btree_gist,cube PGREGRESS_DIR=$D/pgc PGREGRESS_DB=contrib_regression \
PGREGRESS_PORT=52985 PGREGRESS_CONTAINER=a149-cref PGREGRESS_ENGINE_CONTAINER=a149-psql2 \
PGREGRESS_REPORT_DIR=$D/pgc/report PGREGRESS_ENGINE_BIN=$E \
  nice -n 19 $D/vbin/pg_contrib --ignored --nocapture > $D/vi-contrib.log 2>&1
echo "contrib: $(grep -E '^\| (pgvector|bloom|pg_trgm|btree_gist|cube) \| [0-9]+ \| [0-9]+ \| [0-9]+ \| [0-9]+ ' $D/pgc/report/REPORT.md | awk -F'|' '{printf "%s %s/%s; ", $2, $6, $5}')" >> $O
echo "end2 $(date +%H:%M)" >> $O
