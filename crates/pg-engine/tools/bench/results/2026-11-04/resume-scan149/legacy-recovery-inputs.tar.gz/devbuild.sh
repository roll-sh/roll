#!/bin/sh
# usage: heavy-bg.sh <log> sh devbuild.sh: the dev copy's release engine and q (target-dev)
D=/home/meszmate/.cache/a149
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp CARGO_TARGET_DIR=$D/target-dev
cd $D/dev-src
nice -n 19 cargo build --release -p pg-engine --bin roll-engine --example q 2>&1 | grep -E '^(error|warning)|-->|Finished' | head -40
cp $D/target-dev/release/roll-engine $D/eng-dev 2>/dev/null && cp $D/target-dev/release/examples/q $D/q-dev
