#!/bin/sh
# usage: tpch.sh load <eng|pg> | run <eng bin|pg> <reps>: TPC-H SF1 on the engine (port 52987, data tpch-data) or PostgreSQL (a149-pg)
D=/home/meszmate/.cache/a149
P=52987
B="nice -n 19 taskset -c 28-31 $D/bench --target wire --host 127.0.0.1 --db tpch"
case $1 in
load)
  if [ "$2" = pg ]; then $B --port 52980 createdb tpch-load --sf 1 | tail -1; exit; fi
  sh $D/eng.sh start eng-base $P $D/tpch-data > /dev/null; sleep 1
  $B --port $P createdb tpch-load --sf 1 | tail -1
  sh $D/eng.sh stop $P
  ;;
run)
  if [ "$2" = pg ]; then
    c0=$(awk '/usage_usec/ {print $2}' /sys/fs/cgroup/system.slice/docker-$(cat $D/pg-cid).scope/cpu.stat)
    $B --port 52980 tpch --reps $3 > $D/tpch-pg.out 2>&1
    c1=$(awk '/usage_usec/ {print $2}' /sys/fs/cgroup/system.slice/docker-$(cat $D/pg-cid).scope/cpu.stat)
    echo "pg cpu_s=$(( (c1 - c0) / 1000000 ))"
    exit
  fi
  sh $D/eng.sh start $2 $P $D/tpch-data > /dev/null; sleep 1
  pid=$(cat $D/eng-$P.pid)
  c0=$(awk '{print $14 + $15}' /proc/$pid/stat)
  $B --port $P tpch --reps $3 > $D/tpch-$2.out 2>&1
  c1=$(awk '{print $14 + $15}' /proc/$pid/stat)
  rss=$(awk '/VmHWM/{print $2/1024}' /proc/$pid/status)
  echo "$2 cpu_s=$(( (c1 - c0) / 100 )) peak_rss_mb=$rss"
  sh $D/eng.sh stop $P
  ;;
esac
