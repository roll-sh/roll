#!/bin/sh
# usage: heavy-bg.sh <log> sh verify-inner.sh: every check of a batch in one heavy slot (cargo and
# the harnesses run directly, not through heavy.sh again). A summary line per check goes to
# ~/.cache/a149/vi.out.
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
D=/home/meszmate/.cache/a149
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp CARGO_TARGET_DIR=$D/target
O=$D/vi.out
cd $W
echo "start $(date +%H:%M) $(git rev-parse --short HEAD)" > $O
nice -n 19 cargo test -p pg-engine --no-fail-fast > $D/vi-debug.log 2>&1
echo "debug: $(grep -c '^test result: ok' $D/vi-debug.log) ok, $(grep -c 'FAILED\|panicked' $D/vi-debug.log) failed lines" >> $O
if grep -q 'could not compile' $D/vi-debug.log || grep -q 'FAILED\|panicked' $D/vi-debug.log; then
  echo "stopped: the debug tests failed" >> $O
  exit 1
fi
rm -rf $D/vbin && mkdir -p $D/vbin && cp $D/target/debug/roll-engine $D/vbin/roll-engine-debug
for t in pg_regress pg_isolation difftest pg_dump pg_contrib pgvector_equality crash_random; do
  f=$(ls -t $D/target/debug/deps/$t-* | grep -v '\.d$' | head -1); cp "$f" $D/vbin/$t
done
ROLL_TXN_SPILL_BYTES=4096 nice -n 19 cargo test -p pg-engine --test txn_spill --test toast_storage --test drop_storage --test heap_order_scan --test stored_filters > $D/vi-spill.log 2>&1
echo "spill: $(grep -c '^test result: ok' $D/vi-spill.log) ok, $(grep -c 'FAILED\|panicked' $D/vi-spill.log) failed lines" >> $O
nice -n 19 cargo clippy -p pg-engine --all-targets > $D/vi-clippy.log 2>&1
echo "clippy: $(grep -c '^warning' $D/vi-clippy.log) warnings, $(grep -c '^error' $D/vi-clippy.log) errors; in my files: $(grep -A4 '^warning' $D/vi-clippy.log | grep -cE 'exec/scan.rs|storage/(batch|cols|mod|row).rs|txn/mod.rs')" >> $O
nice -n 19 cargo test --release -p pg-engine --no-fail-fast > $D/vi-release.log 2>&1
echo "release: $(grep -c '^test result: ok' $D/vi-release.log) ok, $(grep -c 'FAILED\|panicked' $D/vi-release.log) failed lines" >> $O
cp $D/target/release/roll-engine $D/eng-vi
cd $W/crates/pg-engine
E=$D/vbin/roll-engine-debug
CRASH_SEEDS=$(seq -s, 1 30) nice -n 19 $D/vbin/crash_random > $D/vi-crash.log 2>&1
echo "crash: $(grep -E '^test result' $D/vi-crash.log | tail -1)" >> $O
rm -rf $D/pgr/report $D/pgr/out
PGREGRESS_DIR=$D/pgr PGREGRESS_DB=regression_a149 PGREGRESS_PORT=52982 \
PGREGRESS_CONTAINER=a149-ref PGREGRESS_ENGINE_CONTAINER=a149-psql \
PGREGRESS_REPORT_DIR=$D/pgr/report PGREGRESS_ENGINE_BIN=$E \
  nice -n 19 $D/vbin/pg_regress pg_regress --exact --ignored --nocapture > $D/vi-regress.log 2>&1
echo "regress: $(grep 'units match' $D/vi-regress.log | tail -1 | cut -c1-60) $(grep -o 'Newly differing units: [0-9]*; newly matching: [0-9]*' $D/pgr/report/REPORT.md | head -1)" >> $O
PGISOLATION_EXTRA=1 PGISOLATION_REF=127.0.0.1:52980 PGISOLATION_PORT=52983 PGISOLATION_ENGINE_BIN=$E \
PGISOLATION_DIR=$D/iso PGISOLATION_REPORT_DIR=$D/iso/report PGISOLATION_DB=isolation_a149 \
  nice -n 19 $D/vbin/pg_isolation --ignored --nocapture > $D/vi-iso.log 2>&1
echo "isolation: $(grep -E 'specs,' $D/vi-iso.log | tail -1 | cut -c1-90)" >> $O
DIFFTEST_REF=127.0.0.1:52980 DIFFTEST_DB=difftest_a149 nice -n 19 $D/vbin/difftest --ignored --nocapture smoke > $D/vi-diff.log 2>&1
echo "difftest: $(grep -E '^test result' $D/vi-diff.log | tail -1 | cut -c1-40)" >> $O
rm -rf $D/pgr/pgdump && mkdir -p $D/pgr/pgdump
PGDUMP_DIR=$D/pgr/pgdump PGDUMP_CLIENT=a149-psql PGDUMP_PORT=52984 PGREGRESS_DIR=$D/pgr PGREGRESS_DB=regression_a149 \
PGDUMP_ENGINE_BIN=$E PGDUMP_REPORT_DIR=$D/pgr/pgdump-report \
  nice -n 19 $D/vbin/pg_dump --ignored --nocapture pg_dump_tap > $D/vi-dump.log 2>&1
echo "pg_dump_tap: $(grep -E 'passed, [0-9]+ failed' $D/vi-dump.log | awk '{p+=$2; f+=$4} END {print p" passed, "f" failed"}')" >> $O
rm -rf $D/pgc/report
PGCONTRIB_ONLY=pgvector,bloom,pg_trgm,btree_gist,cube PGREGRESS_DIR=$D/pgc PGREGRESS_DB=contrib_regression \
PGREGRESS_PORT=52985 PGREGRESS_CONTAINER=a149-cref PGREGRESS_ENGINE_CONTAINER=a149-psql2 \
PGREGRESS_REPORT_DIR=$D/pgc/report PGREGRESS_ENGINE_BIN=$E \
  nice -n 19 $D/vbin/pg_contrib --ignored --nocapture > $D/vi-contrib.log 2>&1
echo "contrib: $(grep -E '^\| (pgvector|bloom|pg_trgm|btree_gist|cube) \| [0-9]+ \| [0-9]+ \| [0-9]+ \| [0-9]+ ' $D/pgc/report/REPORT.md | awk -F'|' '{printf "%s %s/%s; ", $2, $6, $5}')" >> $O
PGVECTOR_REF=127.0.0.1:52988 nice -n 19 $D/vbin/pgvector_equality --ignored --nocapture > $D/vi-veq.log 2>&1
echo "pgvector_equality: $(grep -E 'queries' $D/vi-veq.log | tail -1)" >> $O
echo "end $(date +%H:%M)" >> $O
