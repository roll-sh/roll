#!/bin/sh
# usage (inside a149-perf): sb.sh <bin> <query key> <reps>: instructions per run of a scan_bench sql
# query (compacted data, serial), the setup's (a run with none) taken off
D=/home/meszmate/.cache/a149
case $2 in
textcount) q="SELECT count(*) FROM w WHERE e = 'x7'" ;;
numcount) q="SELECT count(*) FROM n WHERE b = 7" ;;
count) q="SELECT count(*) FROM n" ;;
esac
export TMPDIR=$D/tmp SCAN_STATE=compacted SCAN_WORKERS=0 SCAN_QUERY="$q"
a=$(SCAN_REPS=$3 perf stat -x, -e instructions:u $D/$1 sql 1000000 2>&1 >/dev/null | grep instructions | cut -d, -f1)
b=$(SCAN_REPS=0 perf stat -x, -e instructions:u $D/$1 sql 1000000 2>&1 >/dev/null | grep instructions | cut -d, -f1)
echo "$1 $2: $(( (a - b) / ($3 + 1) )) instructions per run"
