#!/bin/sh
# usage: dev.sh: reseek unit test (debug), then release q and engine
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
D=/home/meszmate/.cache/a149
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp CARGO_TARGET_DIR=$D/target
cd $W
H=crates/pg-engine/tools/heavy.sh
timeout 40000 $H cargo test -p pg-engine --lib -- storage::tests > $D/dev-unit.log 2>&1
echo "unit: $(grep -E '^test result|^error|panicked' $D/dev-unit.log | head -3 | tr '\n' ' ')"
timeout 40000 $H cargo build --release -p pg-engine --bin roll-engine --example q > $D/dev-build.log 2>&1
echo "build: $(grep -E '^error|Finished' $D/dev-build.log | head -2 | tr '\n' ' ')"
