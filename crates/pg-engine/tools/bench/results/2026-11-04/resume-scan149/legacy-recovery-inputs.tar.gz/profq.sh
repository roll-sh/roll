#!/bin/sh
# usage (inside a149-perf): profq.sh <q binary> <setup sql> <measured sql> <out>: perf -g of the measured statements only
D=/home/meszmate/.cache/a149
export TMPDIR=$D/tmp
n=$(grep -c ';' $D/$2)
{ cat $D/$2; echo 'SELECT pg_sleep(1);'; cat $D/$3; echo 'SELECT pg_sleep(1);'; } > $D/$4.sql
Q_TIME=1 nice -n 19 $D/$1 < $D/$4.sql > /dev/null 2> $D/$4.err &
pid=$!
while [ "$(grep -c ' ms ' $D/$4.err)" -lt "$n" ]; do sleep 0.2; done
perf record -F 999 -g -p $pid -o $D/$4.data > /dev/null 2>&1 &
pp=$!
while [ "$(grep -c ' ms ' $D/$4.err)" -lt "$((n + 2 + $(grep -c ';' $D/$3)))" ]; do sleep 0.2; done
kill -INT $pp
wait $pp
wait $pid
tail -3 $D/$4.err
perf script -i $D/$4.data --no-inline -F comm,tid,ip,sym 2>/dev/null > $D/$4.txt
chmod 644 $D/$4.txt
