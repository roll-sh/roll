#!/bin/sh
# usage: waitlog.sh <log> <pattern> <count> [secs]: wait until <pattern> appears <count> times
# (or an error/failure shows, or secs pass), then print the matching lines.
log=$1; pat=$2; n=$3; secs=${4:-570}
t=0
while [ "$t" -lt "$secs" ]; do
  [ "$(grep -cE "$pat" "$log" 2>/dev/null)" -ge "$n" ] && break
  grep -qE '^error(\[|:)|FAILED|panicked at|could not compile' "$log" 2>/dev/null && break
  sleep 10; t=$((t + 10))
done
grep -E "$pat|^error(\[|:)|FAILED|panicked at|could not compile" "$log" | head -40
