#!/bin/sh
# usage: pgb.sh init | run <mode: S|tpcb> <secs> <bin>...: pgbench against engines on one data dir
# (CPU ms per transaction from /proc, peak RSS)
D=/home/meszmate/.cache/a149
P=52986
pgb() { sg docker -c "docker exec -e PGPASSWORD=pw a149-psql pgbench -h 127.0.0.1 -p $P -U postgres $*" 2>&1; }
case $1 in
init)
  sh $D/eng.sh start eng-base $P $D/pgb-data > /dev/null; sleep 1
  sg docker -c "docker exec -e PGPASSWORD=pw a149-psql psql -h 127.0.0.1 -p $P -U postgres -c 'CREATE DATABASE pgb'" > /dev/null 2>&1
  pgb -i -s 10 -q pgb | tail -1
  sh $D/eng.sh stop $P
  ;;
run)
  mode=$2; secs=$3; shift 3
  for b in "$@"; do
    sh $D/eng.sh start $b $P $D/pgb-data > /dev/null; sleep 1
    pid=$(cat $D/eng-$P.pid)
    opt=""; [ "$mode" = S ] && opt="-S"
    pgb $opt -M prepared -c 8 -j 4 -T 5 pgb > /dev/null
    c0=$(awk '{print $14 + $15}' /proc/$pid/stat)
    sg docker -c "docker exec -d a149-perf sh -c 'perf stat -x, -e instructions:u -p $pid -o $D/pgb-stat.txt -- sleep $secs'"
    out=$(pgb $opt -M prepared -c 8 -j 4 -T $secs pgb)
    c1=$(awk '{print $14 + $15}' /proc/$pid/stat)
    sleep 1
    tx=$(echo "$out" | awk '/number of transactions actually processed/ {print $NF}' | cut -d/ -f1)
    tps=$(echo "$out" | awk '/^tps/ {print $3}')
    rss=$(awk '/VmHWM/{print $2/1024}' /proc/$pid/status)
    ins=$(grep instructions $D/pgb-stat.txt | cut -d, -f1)
    echo "$b $mode tps=$tps cpu_ms_per_tx=$(awk "BEGIN{printf \"%.4f\", ($c1-$c0)*10/$tx}") kinsn_per_tx=$(awk "BEGIN{printf \"%.0f\", $ins/$tx/1000}") peak_rss_mb=$rss"
    sh $D/eng.sh stop $P
  done
  ;;
esac
