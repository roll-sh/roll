export PATH=$HOME/.cargo/bin:$PATH
export CARGO_TARGET_DIR=$HOME/.cache/a149/target
export TMPDIR=$HOME/.cache/a149/tmp
export W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
export H=$W/crates/pg-engine/tools/heavy.sh
cd $W
