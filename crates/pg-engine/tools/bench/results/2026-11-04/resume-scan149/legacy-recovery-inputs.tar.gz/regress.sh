#!/bin/sh
# usage: regress.sh: the full regression suite on the private reference a149-ref (debug engine)
D=/home/meszmate/.cache/a149
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp
cd $W/crates/pg-engine
PGREGRESS_DIR=$D/pgr PGREGRESS_DB=regression_a149 PGREGRESS_PORT=52982 \
PGREGRESS_CONTAINER=a149-ref PGREGRESS_ENGINE_CONTAINER=a149-psql \
PGREGRESS_REPORT_DIR=$D/pgr/report PGREGRESS_ENGINE_BIN=$D/vbin/roll-engine-debug \
  timeout 10000 tools/heavy.sh $D/vbin/pg_regress pg_regress --exact --ignored --nocapture > $D/regress.log 2>&1
tail -30 $D/regress.log
