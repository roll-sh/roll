#!/bin/sh
# usage (inside a149-perf): profqflat.sh <q binary> <setup sql> <measured sql> <out>: flat perf of the measured statements
D=/home/meszmate/.cache/a149
export TMPDIR=$D/tmp
n=$(grep -c ';' $D/$2)
{ cat $D/$2; echo 'SELECT pg_sleep(1);'; cat $D/$3; echo 'SELECT pg_sleep(1);'; } > $D/$4.sql
Q_TIME=1 nice -n 19 $D/$1 < $D/$4.sql > /dev/null 2> $D/$4.err &
pid=$!
while [ "$(grep -c ' ms ' $D/$4.err)" -lt "$n" ]; do sleep 0.2; done
perf record -F 999 -p $pid -o $D/$4.data > /dev/null 2>&1 &
pp=$!
while [ "$(grep -c ' ms ' $D/$4.err)" -lt "$((n + 2 + $(grep -c ';' $D/$3)))" ]; do sleep 0.2; done
kill -INT $pp
wait $pp
wait $pid
tail -2 $D/$4.err | head -1
perf report -i $D/$4.data --stdio --no-children --sort symbol 2>/dev/null | grep -v '^#' | grep -v '^$' | head -40 | cut -c1-120
