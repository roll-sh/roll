#!/bin/sh
# usage: profeng.sh <port> <case> <clients> <out> [callgraph]: perf of the running engine while the bench runs
D=/home/meszmate/.cache/a149
pid=$(cat $D/eng-$1.pid)
g=""
[ -n "$5" ] && g="-g"
sg docker -c "docker exec -d a149-perf perf record -F 499 $g -p $pid -o $D/$4.data -- sleep 6"
sleep 0.5
nice -n 19 taskset -c 28-31 $D/bench --target wire --host 127.0.0.1 --port $1 --db bench oltp --rows 200000 --only $2 --clients $3 --secs 5 2>&1 | grep RESULT | tr '\t' ' ' | cut -c1-120
sleep 2
sg docker -c "docker exec a149-perf sh -c 'perf report -i $D/$4.data --stdio --no-children --sort symbol 2>/dev/null | grep -v \"^#\" | grep -v \"^\$\" | head -60'" | cut -c1-150
