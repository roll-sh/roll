#!/bin/sh
# usage: shares.sh <stacks.txt> <frame substring>...: the share of samples under each frame
D=/home/meszmate/.cache/a149
f=$1; shift
for k in "$@"; do python3 -I $D/fold.py $f "$k" 1 1 | head -1; done
