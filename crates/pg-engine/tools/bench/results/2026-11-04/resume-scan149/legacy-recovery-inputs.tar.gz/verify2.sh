#!/bin/sh
# usage: verify2.sh: isolation (+ roll specs), difftest smoke, pg_dump_tap, contrib modules
D=/home/meszmate/.cache/a149
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp
cd $W/crates/pg-engine
H=tools/heavy.sh
E=$D/vbin/roll-engine-debug
mkdir -p $D/iso $D/pgr/pgdump $D/pgc
PGISOLATION_EXTRA=1 PGISOLATION_REF=127.0.0.1:52980 PGISOLATION_PORT=52983 PGISOLATION_ENGINE_BIN=$E \
PGISOLATION_DIR=$D/iso PGISOLATION_REPORT_DIR=$D/iso/report PGISOLATION_DB=isolation_a149 \
  timeout 7000 $H $D/vbin/pg_isolation --ignored --nocapture > $D/v-iso.log 2>&1
echo "isolation: $(grep -E 'permutations|specs' $D/v-iso.log | tail -2 | tr '\n' ' ')"
DIFFTEST_REF=127.0.0.1:52980 DIFFTEST_DB=difftest_a149 \
  timeout 7000 $H $D/vbin/difftest --ignored --nocapture smoke > $D/v-diff.log 2>&1
echo "difftest: $(grep -E '^test result' $D/v-diff.log | tail -1)"
PGDUMP_DIR=$D/pgr/pgdump PGDUMP_CLIENT=a149-psql PGDUMP_PORT=52984 PGREGRESS_DIR=$D/pgr PGREGRESS_DB=regression_a149 \
PGDUMP_ENGINE_BIN=$E PGDUMP_REPORT_DIR=$D/pgr/pgdump-report \
  timeout 7000 $H $D/vbin/pg_dump --ignored --nocapture pg_dump_tap > $D/v-dump.log 2>&1
echo "pg_dump_tap: $(grep -iE 'passed|tests ok|[0-9]+ ?/ ?[0-9]+' $D/v-dump.log | tail -2 | tr '\n' ' ')"
[ -d $D/pgc/src-repo ] || cp -a $D/pgr/src-repo $D/pgc/
PGCONTRIB_ONLY=pgvector,bloom,pg_trgm,btree_gist,cube PGREGRESS_DIR=$D/pgc PGREGRESS_DB=contrib_regression \
PGREGRESS_PORT=52985 PGREGRESS_CONTAINER=a149-cref PGREGRESS_ENGINE_CONTAINER=a149-psql2 \
PGREGRESS_REPORT_DIR=$D/pgc/report PGREGRESS_ENGINE_BIN=$E \
  timeout 7000 $H $D/vbin/pg_contrib --ignored --nocapture > $D/v-contrib.log 2>&1
echo "contrib:"; grep -E '^\| (pgvector|bloom|pg_trgm|btree_gist|cube) ' $D/pgc/report/REPORT.md 2>/dev/null | cut -c1-100
