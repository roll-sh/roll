#!/bin/sh
# usage: eng.sh start <binary> <port> <datadir> | stop <port>
D=/home/meszmate/.cache/a149
case $1 in
start)
  mkdir -p $4
  setsid nohup nice -n 19 taskset -c 20-23 $D/$2 --listen 127.0.0.1:$3 --data $4 --password pw --cache-mb 2048 > $D/eng-$3.log 2>&1 &
  echo $! > $D/eng-$3.pid
  i=0
  until ss -ltn | grep -q "127.0.0.1:$3 " || [ $i -ge 60 ]; do sleep 0.5; i=$((i + 1)); done
  cat $D/eng-$3.pid
  ;;
stop)
  p=$(cat $D/eng-$2.pid)
  kill -INT "$p" 2>/dev/null
  i=0
  while kill -0 "$p" 2>/dev/null && [ $i -lt 120 ]; do sleep 0.5; i=$((i + 1)); done
  kill -0 "$p" 2>/dev/null && kill "$p"
  while kill -0 "$p" 2>/dev/null; do sleep 0.5; done
  rm -f $D/eng-$2.pid
  ;;
esac
