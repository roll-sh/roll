#!/bin/sh
# usage: ab.sh <case> <clients> <secs> <rounds> <bin>...: interleaved engine rounds on one data dir:
# throughput, server CPU and instructions per op, peak RSS
D=/home/meszmate/.cache/a149
case=$1; cl=$2; secs=$3; rounds=$4; shift 4
r=1
while [ $r -le $rounds ]; do
  for b in "$@"; do
    sh $D/eng.sh start $b 52981 $D/eng-data > /dev/null
    sleep 1
    pid=$(cat $D/eng-52981.pid)
    nice -n 19 taskset -c 28-31 $D/bench --target wire --host 127.0.0.1 --port 52981 --db bench oltp --rows 200000 --only $case --clients $cl --secs 2 > /dev/null 2>&1
    sg docker -c "docker exec -d a149-perf sh -c 'perf stat -x, -e instructions:u -p $pid -o $D/ab-stat.txt -- sleep $((secs + 1))'"
    sleep 0.3
    out=$(sh $D/rr.sh eng 52981 $case $cl $secs)
    sleep 1.5
    ops=$(echo "$out" | head -1 | tr ' ' '\n' | awk -F= '$1=="ops"{print $2}')
    tps=$(echo "$out" | head -1 | tr ' ' '\n' | awk -F= '$1=="tps"{print $2}')
    cpu=$(echo "$out" | tail -1 | tr ' ' '\n' | awk -F= '$1=="server_cpu_us"{print $2}')
    ins=$(grep instructions $D/ab-stat.txt | cut -d, -f1)
    rss=$(awk '/VmHWM/{print $2/1024}' /proc/$pid/status)
    echo "$b round $r tps=$tps cpu_us_per_op=$(awk "BEGIN{printf \"%.1f\", $cpu/$ops}") kinsn_per_op=$(awk "BEGIN{printf \"%.0f\", $ins/$ops/1000}") peak_rss_mb=$rss"
    sh $D/eng.sh stop 52981
  done
  r=$((r + 1))
done
