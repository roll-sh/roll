#!/bin/sh
# usage: rr.sh <eng|pg> <port> <case> <clients> <secs>: throughput and server CPU per op
D=/home/meszmate/.cache/a149
cpu() {
  if [ "$1" = eng ]; then
    awk '{print ($14 + $15) * 10000}' /proc/$(cat $D/eng-$2.pid)/stat
  else
    awk '/usage_usec/ {print $2}' /sys/fs/cgroup/system.slice/docker-$(cat $D/pg-cid).scope/cpu.stat
  fi
}
c0=$(cpu $1 $2)
out=$(nice -n 19 taskset -c 28-31 $D/bench --target wire --host 127.0.0.1 --port $2 --db bench oltp --rows 200000 --only $3 --clients $4 --secs $5 2>&1 | grep RESULT | tail -1)
c1=$(cpu $1 $2)
echo "$out" | tr '\t' ' ' | cut -c1-220
echo "$1 server_cpu_us=$((c1 - c0))"
