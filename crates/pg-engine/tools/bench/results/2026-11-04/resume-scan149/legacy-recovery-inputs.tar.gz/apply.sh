#!/bin/sh
# usage: apply.sh setup <bin> | run <secs> <bin>... : 151's apply-like pgbench mix on the pgb data dir
D=/home/meszmate/.cache/a149
P=52986
psql_() { sg docker -c "docker exec -i -e PGPASSWORD=pw a149-psql psql -h 127.0.0.1 -p $P -U postgres -q $*" 2>&1; }
pgb() { sg docker -c "docker exec -e PGPASSWORD=pw a149-psql pgbench -h 127.0.0.1 -p $P -U postgres $*" 2>&1; }
case $1 in
setup)
  sh $D/eng.sh start $2 $P $D/pgb-data > /dev/null
  psql_ -d pgb < $D/apply/extra_setup.sql | tail -2
  sh $D/eng.sh stop $P
  ;;
run)
  secs=$2; shift 2
  cp $D/apply/apply.sql $D/pgr/apply.sql
  for b in "$@"; do
    sh $D/eng.sh start $b $P $D/pgb-data > /dev/null
    pid=$(cat $D/eng-$P.pid)
    pgb -M prepared -n -f $D/pgr/apply.sql -c 8 -j 4 -T 5 pgb > /dev/null
    c0=$(awk '{print $14 + $15}' /proc/$pid/stat)
    out=$(pgb -M prepared -n -f $D/pgr/apply.sql -c 8 -j 4 -T $secs pgb)
    c1=$(awk '{print $14 + $15}' /proc/$pid/stat)
    tx=$(echo "$out" | awk '/number of transactions actually processed/ {print $NF}' | cut -d/ -f1)
    tps=$(echo "$out" | awk '/^tps/ {print $3}')
    rss=$(awk '/VmHWM/{print $2/1024}' /proc/$pid/status)
    echo "$b apply tps=$tps cpu_ms_per_tx=$(awk "BEGIN{printf \"%.3f\", ($c1-$c0)*10/$tx}") peak_rss_mb=$rss"
    sh $D/eng.sh stop $P
  done
  ;;
esac
