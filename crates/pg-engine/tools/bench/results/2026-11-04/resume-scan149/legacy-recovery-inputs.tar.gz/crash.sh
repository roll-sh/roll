#!/bin/sh
# usage: crash.sh: crash_random seeds 1-30 (debug test binary of the verified commit)
D=/home/meszmate/.cache/a149
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp
cd $W/crates/pg-engine
CRASH_SEEDS=$(seq -s, 1 30) timeout 7000 tools/heavy.sh $D/vbin/crash_random > $D/v-crash.log 2>&1
grep -E '^test result|panicked|FAILED' $D/v-crash.log | head -5
