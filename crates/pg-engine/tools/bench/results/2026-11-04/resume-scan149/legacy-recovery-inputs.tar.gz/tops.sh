#!/bin/sh
# usage (inside a149-perf): tops.sh <out> <n> [extra perf report args]: inclusive shares
D=/home/meszmate/.cache/a149
f=$1; n=${2:-70}; shift; shift
perf report -i $D/$f.data --stdio --children --sort symbol -g none "$@" 2>&1 | grep -v '^#' | grep -v '^$' | head -$n | cut -c1-170
