#!/bin/sh
# usage: proftpcb.sh <bin> <clients> <out>: perf (frame pointers) of the engine during pgbench tpcb-like
D=/home/meszmate/.cache/a149
P=52986
pgb() { sg docker -c "docker exec -e PGPASSWORD=pw a149-psql pgbench -h 127.0.0.1 -p $P -U postgres $*" 2>&1; }
sh $D/eng.sh start $1 $P $D/pgb-data > /dev/null
pid=$(cat $D/eng-$P.pid)
pgb -M prepared -c $2 -j 4 -T 5 pgb > /dev/null
sg docker -c "docker exec -d a149-perf perf record -F 499 -g --pid $pid -o $D/$3.data -- sleep 12"
sleep 2
pgb -M prepared -c $2 -j 4 -T 13 pgb | grep -E '^tps'
sleep 2
sh $D/eng.sh stop $P
sg docker -c "docker exec a149-perf sh $D/script.sh $3"
