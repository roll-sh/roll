#!/bin/sh
# usage: vec.sh: contrib pgvector against a plain build, then pgvector_equality against a seeded one
D=/home/meszmate/.cache/a149
W=/home/meszmate/roll/.claude/worktrees/agent-a814fa71b51112148
export PATH=/home/meszmate/.cargo/bin:/usr/local/bin:/usr/bin:/bin TMPDIR=$D/tmp
cd $W/crates/pg-engine
E=$D/vbin/roll-engine-debug
sleep 10
PGCONTRIB_ONLY=pgvector PGREGRESS_DIR=$D/pgc PGREGRESS_DB=contrib_regression \
PGREGRESS_PORT=52985 PGREGRESS_CONTAINER=a149-cref PGREGRESS_ENGINE_CONTAINER=a149-psql2 \
PGREGRESS_REPORT_DIR=$D/pgc/report-vec PGREGRESS_ENGINE_BIN=$E \
  timeout 7000 tools/heavy.sh $D/vbin/pg_contrib --ignored --nocapture > $D/v-vec.log 2>&1
grep -E '^\| pgvector ' $D/pgc/report-vec/REPORT.md
PGVECTOR_REF=127.0.0.1:52988 timeout 7000 tools/heavy.sh $D/vbin/pgvector_equality --ignored --nocapture > $D/v-veq.log 2>&1
grep -E '^test result|match|equal' $D/v-veq.log | tail -4
