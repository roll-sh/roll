#!/bin/sh
# usage (inside a149-perf): rep.sh <out> <mode>: dso | callers <symbol>
D=/home/meszmate/.cache/a149
case $2 in
dso) perf report -i $D/$1.data --stdio --no-children --sort dso 2>/dev/null | grep -v '^#' | grep -v '^$' | head -8 ;;
callers) perf report -i $D/$1.data --stdio --no-children --sort symbol -G --symbol-filter="$3" 2>/dev/null | grep -v '^#' | grep -v '^$' | head -40 | cut -c1-140 ;;
esac
