#!/bin/sh
# usage: qrun.sh <sql file> <binary names...>: each binary's statement timings
cd /home/meszmate/.cache/a149
export TMPDIR=/home/meszmate/.cache/a149/tmp
sql=$1; shift
for b in "$@"; do
  echo "== $b"
  Q_TIME=1 ./q-$b < $sql 2>&1 >/dev/null | cut -c1-90
done
